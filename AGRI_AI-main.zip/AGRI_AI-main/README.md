**Crop Recomender:** https://krushisathirecom.streamlit.app/ 

**Farming Help:** https://agriappai.streamlit.app/

**Crop Disease Predictor:** https://agriappai.streamlit.app/

**Smart Crop Price Advisor:** https://krushiprice.streamlit.app/
